﻿/*****************************************************************************
 *  @file     Common/datatypes.h                                             *
 *  @brief    Common data types definitions.                                 *
 *                                                                           *
 *  @author   Yaping Xin                                                     *
 *  @link     https://github.com/yapingxin                                   *
 *  @version  0.1.0.0                                                        *
 *  @date     2025-12-03                                                     *
 *---------------------------------------------------------------------------*
 *  Copyright 2025 Yaping Xin                                                *
 *                                                                           *
 *  Licensed under the Apache License, Version 2.0 (the "License");          *
 *  you may not use this file except in compliance with the License.         *
 *  You may obtain a copy of the License at                                  *
 *                                                                           *
 *      http://www.apache.org/licenses/LICENSE-2.0                           *
 *                                                                           *
 *  Unless required by applicable law or agreed to in writing, software      *
 *  distributed under the License is distributed on an "AS IS" BASIS,        *
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. *
 *  See the License for the specific language governing permissions and      *
 *  limitations under the License.                                           *
 *---------------------------------------------------------------------------*
 *  Change History :                                                         *
 *---------------------------------------------------------------------------*
 *  2025/12/03 | 0.1.0.0   | Yaping Xin     | Create file                    *
 *---------------------------------------------------------------------------*
 *                                                                           *
 *************************************************************************** */

#ifndef _INC_COMMON_datatypes_H
#define _INC_COMMON_datatypes_H

#include <stdbool.h>
#include <stddef.h>

#if _MSC_VER && _MSC_VER < 1700
typedef __int8              int8_t;
typedef __int16             int16_t;
typedef __int32             int32_t;
typedef __int64             int64_t;
typedef unsigned __int8     uint8_t;
typedef unsigned __int16    uint16_t;
typedef unsigned __int32    uint32_t;
typedef unsigned __int64    uint64_t;
#else
#include <stdint.h>
#endif

typedef float           float32_t;
typedef double          float64_t;
typedef unsigned char	byte;
typedef char            sbyte;

#ifdef _WIN64
#define ssize_t __int64
#else
#define ssize_t long
#endif

// ========================================
// Definition of reserved values
// ----------------------------------------
#define UInt8_MAX       0xFF
#define UInt8_NOP       0xFF
#define UInt8_ANY       0xFF

#define UInt16_MAX      0xFFFF
#define UInt16_NOP      0xFFFF
#define UInt16_ANY      0xFFFF

#define UInt16_ERR01    (UInt16_MAX - 1)
#define UInt16_ERR02    (UInt16_MAX - 2)

#define UInt32_MAX      0xFFFFFFFF
#define UInt32_NOP      0xFFFFFFFF
#define UInt32_ANY      0xFFFFFFFF

#define Int32_MAX       0x7FFFFFFF

#define UInt64_MAX      0xFFFFFFFFFFFFFFFF
#define UInt64_NOP      0xFFFFFFFFFFFFFFFF
#define UInt64_ANY      0xFFFFFFFFFFFFFFFF
// ========================================

/****************************************************************************
 * HResult
 ****************************************************************************/
#ifndef DATATYPES_HResult
#define DATATYPES_HResult 1

typedef uint32_t HResult;

#define HResult_Unknown 0
#define HResult_OK      1
#define HResult_DONE    0x00007FDE

#define HResult_FAILED              0x00100000
#define HResult_PARAM_NULL          0x00110000
#define HResult_PARAM_OUTRANGE      0x00120000
#define HResult_PARAM_INVALID       0x00120001
#define HResult_BUF_NOSPACE         0x00120002
#define HResult_BUF_NOENOUGHDATA    0x00120003
#define HResult_FILE_NO_ACCESS      0x00130000
#define HResult_FILE_NOTEXISTS      0x00130001
#define HResult_FILE_CannotRead     0x00130002
#define HResult_FILE_CannotWrite    0x00130004
#define HResult_FILE_CannotCreate   0x00130005
#define HResult_FILE_MovePtrFail    0x00130006
#define HResult_FILE_SetFendFail    0x00130007
#define HResult_FILE_IsEmpty        0x00130008
#define HResult_DIR_LOOKUP_FAILED   0x00130010
#define HResult_PATH_RetrieveFail   0x00130020
#define HResult_FILE_OPEN_FAIL      0x00130040
#define HResult_DIR_CREATE_FAIL     0x00130080
#define HResult_DIR_NOTFOUND        0x00130081
#define HResult_MODULE_NotFound     0x00140001
#define HResult_MODULE_LOAD_FAIL    0x00140002
#define HResult_SYMBLE_LOAD_FAIL    0x00140003

#define HResult_FILEMAP_CREATEFAIL  0x00150001
#define HResult_FILEVIEWMAP_CRFAIL  0x00150002

#define HResult_SERIAL_OpenFail     0x00160001
#define HResult_SERIAL_CloseFail    0x00160002
#define HResult_SERIAL_SendFail     0x00160004

// MSDN Topic: Windows Sockets Error Codes
// MSDN Link: https://docs.microsoft.com/zh-cn/windows/win32/winsock/windows-sockets-error-codes-2
#define HResult_SOCKET_FAIL               0x7E000000
#define HResult_SOCKET_WSAEINTR           (0x7E000000 + 10004)
#define HResult_SOCKET_WSAEFAULT          (0x7E000000 + 10014)
#define HResult_SOCKET_WSAEWOULDBLOCK     (0x7E000000 + 10035)
#define HResult_SOCKET_WSAEINPROGRESS     (0x7E000000 + 10036)
#define HResult_SOCKET_WSAENOTSOCK        (0x7E000000 + 10038)
#define HResult_SOCKET_WSAENETDOWN        (0x7E000000 + 10050)
#define HResult_SOCKET_WSAEPROCLIM        (0x7E000000 + 10067)
#define HResult_SOCKET_WSASYSNOTREADY     (0x7E000000 + 10091)
#define HResult_SOCKET_WSAVERNOTSUPPORTED (0x7E000000 + 10092)
#define HResult_SOCKET_WSANOTINITIALISED  (0x7E000000 + 10093)
#define HResult_SOCKET_TypeNotSupported   0x7E000001
#define HResult_SOCKET_INVALID            0x7E000002
#define HResult_SOCKET_SetOptFailed       0x7E000003
#define HResult_SOCKET_BindFailed         0x7E000004

#define HResult_ICMP_PINGOK                 HResult_OK
#define HResult_ICMP_BASE                   0x7E100000
#define HResult_ICMP_IPBUFTOOSMALL          0x7E100001
#define HResult_ICMP_IPDESTNET_UNREACHABLE  0x7E100002
#define HResult_ICMP_IPDESTHOSTUNREACHABLE  0x7E100003
#define HResult_ICMP_IPREQ_TIMEOUT          0x7E10000A
#define HResult_ICMP_IPERROR                0x7E1000FF

#define HResult_ALLOC_FAIL          0x00170000
#define HResult_DATA_INVALID        0x00180000
#define HResult_PROC_INVALID        0x00180001
#define HResult_MEM_OVERFLOW        0x00180002
#define HResult_NOT_SUPPORTED       0x00180004
#define HResult_OBJECT_IS_NULL      0x00190000
#define HResult_DECODEOUTRANGE      0x001B0000
#define HResult_DECODE_FAIL         0x001B0001
#define HResult_DECODE_CHKFAIL      0x001B0002
#define HResult_DECODE_CRCFAIL      0x001B0004
#define HResult_DECODE_SUMFAIL      0x001B0008

#define HResult_CUSTOM_7F_FAIL      0x7F000000

#define HResult_SQLite3OpenFail     0x00140001
#define HResult_SQLite3QueryFail    0x00150001
#define HResult_SQLite3QueryNULL    0x00150002
#define HResult_SQLite3ExecFailed   0x00150004
#define HResult_SQLite3PrepareErr   0x00150008

#define HRESULT_timeGetDevCapsFAIL  0x00160001
#define HResult_WMTIMER_PERSETFAIL  0x00160002
#define HResult_WMTIMER_PEROUTRANGE 0x00160003
#define HResult_WMTIMER_CreateEvt   0x00160004

#endif // !DATATYPES_HResult

#endif // !_INC_COMMON_datatypes_H
