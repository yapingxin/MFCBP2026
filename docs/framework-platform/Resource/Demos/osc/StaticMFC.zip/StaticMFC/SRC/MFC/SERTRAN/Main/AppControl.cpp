﻿#include "AppControl.h"

AppUIControls* AppControl::GetUIControls()
{
	return &m_UIControls;
}

