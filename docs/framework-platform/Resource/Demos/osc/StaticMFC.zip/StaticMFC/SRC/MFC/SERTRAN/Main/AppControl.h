﻿#ifndef _INC_MFCUTILITY_MAIN_AppControl_H
#define _INC_MFCUTILITY_MAIN_AppControl_H

#include "framework.h"
#include "Common/datatypes.h"

typedef struct _AppUIControls_t
{
    _AppUIControls_t()
    {
        MainWindow = NULL;
    }

    CWnd* MainWindow;   // 程序主窗体指针
} AppUIControls;

class AppControl
{
public:
    AppUIControls* GetUIControls();

private:
    AppUIControls m_UIControls;
};

#endif // !_INC_MFCUTILITY_MAIN_AppControl_H
